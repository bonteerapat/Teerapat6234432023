package Lab10_2_Bus;

import static Lab10_2_Bus.Electric.HIGH_VOLTAGE;
import static Lab10_2_Bus.Electric.LOW_VOLTAGE;

public class Hybrid extends Bus implements LiquidFuel,Electric {
    // instance variable
    private double voltage;
    private double range;
    private int emissionTier;
    // constructor
    public Hybrid(int capacity, double cost, double voltage, double range, int emissionTier) {
        super(capacity, cost);
        this.voltage = voltage;
        this.range = range;
        this.emissionTier = emissionTier;
        if (voltage < LOW_VOLTAGE) {
            this.voltage = LOW_VOLTAGE;
        } else if (voltage > HIGH_VOLTAGE) {
            this.voltage = HIGH_VOLTAGE;
        }
    }
    // method
    public double getRange() {
        return range;
    }
    public int getEmissionTier() {
        return emissionTier;
    }
    public double getVoltage() {
        return voltage;
    }
    public double getAccel() {
        return 4.0;
    }
    public String toString(){
        return "ID : " + getID() + "\n" + "Emission Tier : " + getEmissionTier() + "\n" + "Accel : " + getAccel();
    }
}

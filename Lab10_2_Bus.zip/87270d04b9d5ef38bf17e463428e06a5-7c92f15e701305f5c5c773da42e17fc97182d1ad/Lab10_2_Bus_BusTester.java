package Lab10_2_Bus;

import java.util.ArrayList;

public class BusTester {
    public static void main(String[] args){
        ArrayList<Bus> arr = new ArrayList<>();

        Hybrid hybrid_bus = new Hybrid(45,1.2,600,150,1);
        arr.add(hybrid_bus);
        CNGBus cng_bus = new CNGBus(50,1,200,2);
        arr.add(cng_bus);
        for(Bus i : arr){
            if(i instanceof Hybrid){
                System.out.println(i.toString());
            }
            if(i instanceof  CNGBus){
                System.out.println(i.toString());
            }
        }
    }
}

package Lab10_2_Bus;

public class CNGBus extends Bus implements LiquidFuel{
    // instance variable
    private double range;
    private int emissionTier;
    // constructor
    public CNGBus(int capacity,double cost,double range,int emissionTier){
        super(capacity,cost);
        this.range = range;
        this.emissionTier = emissionTier;
    }
    // method
    public double getRange(){
        return range;
    }
    public int getEmissionTier(){
        return emissionTier;
    }
    public double getAccel(){
        return 3.0;
    }
    public String toString(){
        return "ID : " + getID() + "\n" + "Emission Tier : " + getEmissionTier() + "\n" + "Accel : " + getAccel();
    }

}

package Lab10_2_Bus;

public interface LiquidFuel {
    double getRange();
    int getEmissionTier();
}

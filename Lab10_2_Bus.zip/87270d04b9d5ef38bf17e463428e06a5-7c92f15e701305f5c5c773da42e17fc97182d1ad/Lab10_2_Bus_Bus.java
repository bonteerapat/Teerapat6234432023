package Lab10_2_Bus;

public abstract class Bus {
    // instance variable
    private int ID;
    private int capacity;
    private double cost;
    private static int nextID = 1;
    // constructor
    public Bus(int capacity,double cost){
        ID = nextID++;
        this.capacity = capacity;
        this.cost = cost*Math.pow(10,6); // ex. 1.2 (x10^6)million baht
    }
    // abstract method
    public abstract double getAccel();
    // method
    public final int getID(){
        return ID;
    }
    public int getCapacity(){
        return capacity;
    }
    public double getCost(){
        return cost;
    }
}

package Lab9_1_Pizza;

public class Pizza {
    // instance variable
    private String name;
    private double price;
    // constructor
    public Pizza(String name,double price){
        this.name = name;
        this.price = price;
    }
    // method
    public String getName(){
        return name;
    }
    public double getPrice(){
        return price;
    }
    public String toString(){
        return name + " price : " + price;
    }
}

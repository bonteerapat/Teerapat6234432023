package Lab9_1_Pizza;

public class GoldCustomer extends Customer {
    // instance variable
    private double discount;
    // constructor
    public GoldCustomer(String name,String tel,double discount_input){
        super(name,tel);
        this.discount = discount_input;
    }
    // method
    public double getDiscount(){
        return discount;
    }
    public String toString(){
        return super.toString() + " discount : " + discount;
    }
}

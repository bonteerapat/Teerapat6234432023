package Lab9_1_Pizza;

import java.util.ArrayList;

public class Order {
    // instance variable
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p = new ArrayList<Pizza>();
    // constructor
    public Order(Customer c){
        this.c = c;
        cntOrder++;
        id = cntOrder;
    }
    // method
    public void addPizza(Pizza pizza){
        p.add(pizza);
    }
    public String getOrderDetail(){
        String order_id = "Order id : " + getId() + "\n";
        String pizza_detail = "";
        for(int i=0;i<p.size();i++){
            pizza_detail += p.get(i).toString() + "\n";
        }
        return order_id + c.toString() + "\n" + pizza_detail + "Total pieces : " + p.size() + " \n" + "Total cost : " + calculatePayment();
    }
    public double calculatePayment(){
        double total_price = 0;
        for(int i=0;i<p.size();i++){
            total_price += p.get(i).getPrice();
        }
        double discount = c.getDiscount()*0.01;
        total_price -= total_price*discount;
        return total_price;
    }
    public int getId(){
        return id;
    }
}

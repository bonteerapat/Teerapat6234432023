package Lab3_2_Letter;

public class Letter {
    private String addresser;
    private String addressee;
    private String text;
    public Letter(String from,String to){
        addresser = from;
        addressee = to;
        text = "";
    }
    public void addLine(String line){
        text = text + "\n" + line;
    }
    public String getText(){
        String letter = "Dear "+addresser + "\n" + text +"\n" +"\n" +"Sincerely," +"\n" +"\n" + addressee;
        return letter;
    }
}

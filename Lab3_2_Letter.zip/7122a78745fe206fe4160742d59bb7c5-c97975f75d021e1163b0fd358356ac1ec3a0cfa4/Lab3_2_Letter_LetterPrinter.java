package Lab3_2_Letter;

public class LetterPrinter {
    public static void main(String[] args){
        Letter let = new Letter("Jade","Clarissa");
        let.addLine("WE must find Simon quickly.");
        let.addLine("He might be in danger.");
        System.out.println(let.getText());
    }
}

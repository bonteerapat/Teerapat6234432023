package Lab12_1_SequentialTextFile;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class SequentialTextFile {
    public static void main(String[] args) throws FileNotFoundException {
        String string = "";
        int count_char = 0;
        int count_word = 0;
        int count_line = 0;

        Scanner scan = new Scanner(System.in);
        boolean first_line = true;

        while(true){
            String line = scan.nextLine();
            if(line.equals("quit")){
                break;
            }else{
                if(!first_line){
                    string += "\n";
                    string += line;
                }else{
                    string += line;
                    first_line = false;
                }
            }
        }
        File file = new File("output.txt");
        PrintWriter output = new PrintWriter(file);
        output.print(string);
        output.close();

        Scanner read = new Scanner(file);
        while(read.hasNextLine()){
            String line = read.nextLine();
            count_line++;
            String[] word_array = line.split(" ");
            count_word += word_array.length;
            count_char += line.length();
        }
        read.close();

        System.out.printf("Total characters : %d \n",count_char);
        System.out.printf("Total words : %d \n",count_word);
        System.out.printf("Total lines : %d \n",count_line);
    }
}

package Lab8_1_Car;

public class Truck extends Car {
    private double M_weigth;
    private double weight;
    public Truck(double gas,double efficiency,double Max_weight,double weight){
        super(gas,efficiency);
        if(weight > Max_weight){
            weight = Max_weight;
        }
        this.M_weigth = Max_weight;
        this.weight = weight;
    }
    public void drive(double distance){
        double truckOil = distance/this.getEfficiency(); // truckOil = 100/20 = 5
        if(weight < 1){
            truckOil += 0;
        }else if(weight <= 10){
            truckOil += 0.1*truckOil;
        }else if(weight <= 20){
            truckOil += 0.2*truckOil; // weight = 15 so truckOil = 5 + (0.2*5) = 6
        }else if(weight > 20){
            truckOil += 0.3*truckOil;
        }
        distance = this.getEfficiency()*truckOil;
        super.drive(distance); // distance = 100 , eff = 20
    }
}

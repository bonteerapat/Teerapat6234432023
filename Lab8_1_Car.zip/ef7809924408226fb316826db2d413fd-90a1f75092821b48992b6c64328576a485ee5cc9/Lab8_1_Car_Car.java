package Lab8_1_Car;

public class Car {
    private double gas; // number of cartridge จำนวนน้ำมัน
    private double efficiency; // rate (distance / volume) อัตราการใช้น้ำมัน : ระยะทาง/ปริมาตร
    public Car(){
        gas =0;
        efficiency = 0;
    }
    public Car(double gas,double efficiency){
        this.gas = gas;
        this.efficiency = efficiency;
    }
    public void drive(double distance){
        double amountOil = distance/efficiency;
        if(amountOil > gas){
            System.out.println("You cannot drive too far,please add gas");
        }else if(0 < amountOil && amountOil <= gas){
            gas -= amountOil;
        }
    }
    public void setGas(double amount){
        gas = amount;
    }
    public double getGas(){
        return gas;
    }
    public double getEfficiency(){
        return efficiency;
    }
    public void addGas(double amount){
        gas += amount;
    }

}

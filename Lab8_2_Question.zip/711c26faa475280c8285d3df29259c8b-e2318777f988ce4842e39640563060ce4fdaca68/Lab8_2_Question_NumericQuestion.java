package Lab8_2_Question;

public class NumericQuestion extends Question {
    public NumericQuestion(String text){
        super(text);
    }
    public boolean checkAnswer(String response){
        double different = Math.abs(Double.parseDouble(response) - Double.parseDouble(this.getAnswer()));
        boolean bool_check = super.checkAnswer(response);
        if(bool_check && (different <= 0.01)){
            return true;
        }else{
            return false;
        }
    }
}

package Lab8_2_Question;

public class Question {
    // instance variables
    private String text;
    private String answer;
    // constructor
    public Question(){
        text = "";
        answer = "";
    }
    public Question(String text){
        this.text = text;
    }
    // methods
    public void setText(String text){
        this.text = text;
    }
    public String getText(){
        return text;
    }
    public void setAnswer(String answer){
        this.answer = answer;
    }
    public String getAnswer(){
        return answer;
    }
    public boolean checkAnswer(String response){
        if(response.equals(answer)){
            return true;
        }else{
            return false;
        }
    }
    public void display(){
        System.out.println(text);
    }
}

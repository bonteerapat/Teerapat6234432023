package Lab8_2_Question;

import java.util.ArrayList;

public class ChoiceQuestion extends Question {
    private ArrayList<String> choices;
    public ChoiceQuestion(String question){
        super(question);
        choices = new ArrayList<>();
    }
    public void addChoice(String choice,boolean correct){
        choices.add(choice);
        if(correct){
            this.setAnswer(choice);
        }
    }
    public boolean checkAnswer(String response){ // response = 2
        int num_response = Integer.parseInt(response); // num_response = 2(int) = 2
        if(num_response == choices.indexOf(this.getAnswer())+1){
            return true;
        }else{
            return false;
        }
    }
    public void display(){
        super.display();
        for(int i=0;i<choices.size();i++){
            System.out.println(i+1 + " : " + choices.get(i));
        }
    }
}

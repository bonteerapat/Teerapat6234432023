package Lab12_3_Bank;

public class TransactionRecord {
    // instance variable
    private int acctNo;
    private double balance;
    private int transCnt;
    // constructor
    public TransactionRecord(int acctNo,double balance){
        this.acctNo = acctNo;
        this.balance = balance;
        this.transCnt = 1;
    }
    // method
    public int getAcctNo(){
        return acctNo;
    }
    public void setAcctNo(int acctNo){
        this.acctNo = acctNo;
    }
    public double getBalance(){
        return balance;
    }
    public void setBalance(double balance){
        this.balance = balance;
    }
    public int getTransCnt(){
        return transCnt;
    }
    public void setTransCnt(int transCnt){
        this.transCnt = transCnt;
    }
    public String toString(){
        return "Transaction { " + "account number = " + acctNo
                + " ,balance = " + balance + " ,trans_count = " + transCnt
                + " }";
    }
}

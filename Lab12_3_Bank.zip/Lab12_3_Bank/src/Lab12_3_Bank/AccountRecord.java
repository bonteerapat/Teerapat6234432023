package Lab12_3_Bank;

public class AccountRecord {
    // instance variable
    private int acctNo;
    private String name;
    private double balance;
    private int transCnt;
    // constructor
    public AccountRecord(int acctNo,String name,double balance){
        this.acctNo = acctNo;
        this.name = name;
        this.balance = balance;
        transCnt = 0;
    }
    public AccountRecord(int acctNo,String name,double balance,int transCnt){
        this.acctNo = acctNo;
        this.name = name;
        this.balance = balance;
        this.transCnt = transCnt;
    }
    // method
    public int getAcctNo(){
        return acctNo;
    }
    public String getName(){
        return name;
    }
    public double getBalance(){
        return balance;
    }
    public int getTransCnt(){
        return transCnt;
    }
    public String toString(){
        return "AccountRecord{" + " account number = " + acctNo
                + " ,name = " + name + " ,balance = " + balance
                + " trans_count = " + transCnt + "}";
    }
    public void combine(TransactionRecord transactionRecord){
        if(transactionRecord.getAcctNo() != this.getAcctNo()){
            return;
        }
        this.balance += transactionRecord.getBalance();
        this.transCnt += transactionRecord.getTransCnt();
    }
}

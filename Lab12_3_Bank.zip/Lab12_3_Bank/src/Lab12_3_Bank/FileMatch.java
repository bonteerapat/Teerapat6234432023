package Lab12_3_Bank;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;

public class FileMatch {
    public static void main(String[] args){
        ArrayList<AccountRecord> accountRecordArrayList = new ArrayList<>();
        ArrayList<TransactionRecord> transactionRecordArrayList = new ArrayList<>();

        File master = new File("master.txt");
        try(Scanner scan_master = new Scanner(master)){
            while(scan_master.hasNextLine()){
                String line = scan_master.nextLine();
                String[] split_in_master = line.split(" ");
                int accNo = Integer.parseInt(split_in_master[0]);
                String name = split_in_master[1] + " " + split_in_master[2];
                double balance = Double.parseDouble(split_in_master[3]);
                AccountRecord accountRecord = new AccountRecord(accNo,name,balance);
                accountRecordArrayList.add(accountRecord);
            }
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }

        File trans = new File("trans.txt");
        try(Scanner scan_trans = new Scanner(trans)){
            while(scan_trans.hasNextLine()){
                String line = scan_trans.nextLine();
                String[] split_in_trans = line.split(" ");
                int accNo = Integer.parseInt(split_in_trans[0]);
                double balance = Double.parseDouble(split_in_trans[1]);
                if(transactionRecordArrayList.size() != 0){
                    TransactionRecord trans_last = transactionRecordArrayList.get(transactionRecordArrayList.size() - 1);
                    if(trans_last.getAcctNo() == accNo){
                        trans_last.setBalance(trans_last.getBalance() + balance);
                        trans_last.setTransCnt(trans_last.getTransCnt() + 1);
                    }else{
                        TransactionRecord transactionRecord = new TransactionRecord(accNo,balance);
                        transactionRecordArrayList.add(transactionRecord);
                    }
                }else{
                    TransactionRecord transactionRecord = new TransactionRecord(accNo,balance);
                    transactionRecordArrayList.add(transactionRecord);
                }
            }
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }
        for(AccountRecord account : accountRecordArrayList){
            for(TransactionRecord transactionRecord : transactionRecordArrayList){
                if(account.getAcctNo() == transactionRecord.getAcctNo()){
                    account.combine(transactionRecord);
                    break;
                }
            }
        }
        try(RandomAccessFile randomAccessFile = new RandomAccessFile("newMaster.dat","rw")){
            for(AccountRecord accountRecord : accountRecordArrayList){
                randomAccessFile.writeInt(accountRecord.getAcctNo());
                randomAccessFile.writeChar('\n');
                String name = accountRecord.getName();
                for(int i = name.length();i<30;i++){
                    name += " ";
                }
                randomAccessFile.writeChars(name);
                randomAccessFile.writeChar('\n');
                randomAccessFile.writeDouble(accountRecord.getBalance());
                randomAccessFile.writeChar('\n');
                randomAccessFile.writeInt(accountRecord.getTransCnt());
                randomAccessFile.writeChar('\n');
            }
        } catch (IOException e){
            e.printStackTrace();
        }
        ArrayList<AccountRecord> accountRecords_read = new ArrayList<>();
        try(RandomAccessFile randomAccessFile = new RandomAccessFile("newMaster.dat","r")){
            while(randomAccessFile.getFilePointer() < randomAccessFile.length()){
                int accNo = randomAccessFile.readInt();
                randomAccessFile.seek(randomAccessFile.getFilePointer() + 2);
                String name = randomAccessFile.readLine();
                Double balance = randomAccessFile.readDouble();
                randomAccessFile.seek(randomAccessFile.getFilePointer() + 2);
                int transCnt = randomAccessFile.readInt();
                randomAccessFile.seek(randomAccessFile.getFilePointer() + 2);
                AccountRecord accountRecord = new AccountRecord(accNo,name,balance,transCnt);
                accountRecords_read.add(accountRecord);
            }
        }catch (IOException e){
            e.printStackTrace();
        }
        double balance = 0;
        int no_trans = 0;
        for(AccountRecord accountRecord : accountRecords_read){
            balance += accountRecord.getBalance();
            if(accountRecord.getTransCnt() == 0){
                no_trans++;
            }
        }
        System.out.print("Total Account Record : ");
        System.out.println(accountRecords_read.size());
        System.out.print("Total Balance : ");
        System.out.println(balance);
        System.out.print("No transaction : ");
        System.out.println(no_trans + " account.");
    }

}
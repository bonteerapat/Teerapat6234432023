package Lab3_3_CashRegister;

public class CashRegister {
    private double purchase;
    private double taxable_purchase;
    private double payment;
    public final double rate_tax;
    public CashRegister(){
        purchase = 0;
        taxable_purchase = 0;
        payment = 0;
        rate_tax = 0.07;
    }
    public void recordPurchase(double amount){
        purchase += amount;
    }
    public void recordTaxablePurchase(double amount){
        taxable_purchase += amount + (rate_tax*amount);
    }
    public double getTotalTax(){
        return taxable_purchase;
    }
    public void enterPayment(double amount){
        payment += amount;
    }
    public double giveChange(){
        double change = payment - (purchase + taxable_purchase);
        purchase = 0;
        payment = 0;
        taxable_purchase = 0;
        return change;
    }

}

package Lab3_1_InsectPopulation;

public class InsectPopulation {

        //private double init_population;
        private double population;
        public InsectPopulation(double init_population){
            population = init_population;
        }
        public void breed(){
            population = 2*population;
        }
        public void spray(){
            population = population-(0.1*population);
        }
        public double getNumInsect(){
            return population;
        }

}

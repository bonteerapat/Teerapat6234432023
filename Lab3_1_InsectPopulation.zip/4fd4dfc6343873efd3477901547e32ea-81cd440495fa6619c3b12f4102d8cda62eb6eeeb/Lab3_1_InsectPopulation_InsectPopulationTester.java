package Lab3_1_InsectPopulation;

public class InsectPopulationTester {
    public static void main(String[] args){
        InsectPopulation insectPop = new InsectPopulation(10);
        insectPop.breed();
        insectPop.spray();
        System.out.println("Number of insects: " + (float) insectPop.getNumInsect());
        insectPop.breed();
        insectPop.spray();
        System.out.println("Number of insects: " + (float) insectPop.getNumInsect());
        insectPop.breed();
        insectPop.spray();
        System.out.println("Number of insects: " + (float) insectPop.getNumInsect());

    }
}

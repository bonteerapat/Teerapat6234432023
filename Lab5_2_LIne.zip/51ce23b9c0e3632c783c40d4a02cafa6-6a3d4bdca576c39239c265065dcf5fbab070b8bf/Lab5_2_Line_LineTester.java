package Lab5_2_Line;

public class LineTester {
    public static void main(String[] args){
        Line line1 = new Line(-2,1,1,-2);
        Line line2 = new Line(-6,-2,-2,0);
        System.out.println("Are the two lines equals?: " + line1.isEquals(line2));
        System.out.println("Are the two lines parallel?: " + line1.isParallel(line2));
        System.out.println("Are the two lines intersect?: " + line1.isIntersect(line2));
        System.out.println("Point of intersection : " + line1.getIntersectionPoint(line2));
    }
}

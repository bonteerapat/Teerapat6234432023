package Lab9_2_Taylor;

public class cosine extends Taylor{
    public cosine(int k,double x){
        super(k,x);
    }
    public double getApprox(){
        double approx_value = 0;
        for(int n=0;n<this.getter();n++){
            approx_value += (Math.pow((-1),n) * Math.pow(this.getValue(),(2*n)))/(factorial((2*n)));
        }
        return approx_value;
    }
    public void printValue(){
        System.out.println("Value from Math.cos() is " + Math.cos(this.getValue()) + ".");
        System.out.println("Approximated value is " + this.getApprox() + ".");
    }
}

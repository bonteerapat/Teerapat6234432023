package Lab9_2_Taylor;

public abstract class Taylor {
    // instance variable
    private int k;
    private double x;
    // constructor
    public Taylor(int k,double x){
        this.k = k;
        this.x = x;
    }
    // method
    public int factorial(int n){
        int result = 1;
        for(int i=0;i<n;i++){
            result = result*(i+1);
        }
        return result;
    }
    public void setter(int k){
        this.k = k;
    }
    public int getter(){
        return this.k;
    }
    public void setValue(double x){
        this.x = x;
    }
    public double getValue(){
        return this.x;
    }
    public abstract void printValue();
    public abstract double getApprox();

}

package Lab9_2_Taylor;

public class expo extends Taylor {
    public expo(int k,double x){
        super(k,x);
    }
    public double getApprox(){
        double approx_value = 0;
        for(int n=0;n<=this.getter();n++){
            approx_value += (Math.pow(this.getValue(),n))/(factorial(n));
        }
        return approx_value;
    }
    public void printValue(){
        System.out.println("Value from Math.exp() is " + Math.exp(this.getValue()) + ".");
        System.out.println("Approximated value is " + this.getApprox() + ".");
    }
}

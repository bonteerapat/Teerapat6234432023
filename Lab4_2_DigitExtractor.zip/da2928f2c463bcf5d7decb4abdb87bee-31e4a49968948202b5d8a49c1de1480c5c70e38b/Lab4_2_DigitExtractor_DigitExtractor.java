package Lab4_2_DigitExtractor;

public class DigitExtractor {
    private int integer;
    private int digit;
    public DigitExtractor(int num){
        integer = num;
        digit = 0;
    }
    public int nextDigit(){
        digit = integer%10;
        integer = (integer/10);
        return digit;
    }
    /*
    int number = 16834;
        int digit = number%10;
        number = (number/10);
        System.out.println(number); // 1683
        System.out.println(digit); // 4
     */
}

package Lab6_2;

import java.util.Random;
import java.util.Scanner;

public class Game {
    private int user_choose_int;
    private int com_choose_int;
    private int user_score;
    private int com_score;
    public Game(){
        user_choose_int = 0;
        com_choose_int = 0;
        user_score = 0;
        com_score = 0;
    }
    public void play(){

        int total = 0;
        while(total != 2){
            Scanner input = new Scanner(System.in);
            String user_choose_string = "";
            do{
                System.out.print("Enter 0 for ROCK,1 for PAPER,2 for SCISSORS : ");
                user_choose_int = input.nextInt();
            }while(user_choose_int != 0 && user_choose_int != 1 && user_choose_int != 2);
            switch (user_choose_int){
                case 0: user_choose_string = "ROCK"; break;
                case 1: user_choose_string = "PAPER"; break;
                case 2: user_choose_string = "SCISSORS"; break;
            }
            System.out.println("You enter : " + user_choose_string);

            String com_choose_string = "";
            Random rand = new Random();
            com_choose_int = rand.nextInt(3);
            switch (com_choose_int){
                case 0: com_choose_string = "ROCK"; break;
                case 1: com_choose_string = "PAPER"; break;
                case 2: com_choose_string = "SCISSORS"; break;
            }
            System.out.println("Computer : " + com_choose_string);

            if(user_choose_string.equals("ROCK") && com_choose_string.equals("ROCK")){
                System.out.println("It's a tie.");
            }else if(user_choose_string.equals("ROCK") && com_choose_string.equals("PAPER")){
                System.out.println("You lose!");
                com_score += 1;
            }else if(user_choose_string.equals("ROCK") && com_choose_string.equals("SCISSORS")){
                System.out.println("You win!");
                user_score += 1;
            }else if(user_choose_string.equals("PAPER") && com_choose_string.equals("ROCK")){
                System.out.println("You win!");
                user_score += 1;
            }else if(user_choose_string.equals("PAPER") && com_choose_string.equals("PAPER")){
                System.out.println("It's a tie");
            }else if(user_choose_string.equals("PAPER") && com_choose_string.equals("SCISSORS")){
                System.out.println("You lose!");
                com_score += 1;
            }else if(user_choose_string.equals("SCISSORS") && com_choose_string.equals("ROCK")){
                System.out.println("You lose!");
                com_score += 1;
            }else if(user_choose_string.equals("SCISSORS") && com_choose_string.equals("PAPER")){
                System.out.println("You win!");
                user_score += 1;
            }else if(user_choose_string.equals("SCISSORS") && com_choose_string.equals("SCISSORS")){
                System.out.println("It's a tie");
            }

            total = Math.abs(user_score - com_score);
        }
        System.out.println("------------------------------");
        if(user_score > com_score){
            System.out.println("Congrats! You win.");
        }else{
            System.out.println("Too bad! You lose.");
        }
        System.out.println("User score : " + user_score);
        System.out.println("Computer score : " + com_score);

    }
}

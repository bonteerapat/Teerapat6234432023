package Lab7_2_MagicSquare;

public class MagicSquareTester {
    public static void main(String[] args){
        MagicSquare square = new MagicSquare(5);
        System.out.println(square.toString());
    }
}

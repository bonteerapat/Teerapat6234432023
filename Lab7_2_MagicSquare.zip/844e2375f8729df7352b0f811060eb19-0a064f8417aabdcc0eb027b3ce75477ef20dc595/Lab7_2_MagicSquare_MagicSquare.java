package Lab7_2_MagicSquare;

public class MagicSquare {
    private int[][] data;
    public MagicSquare(int num){
        data = new int[num][num];
        int i = num - 1;
        int j = num/2;
        for(int k=1;k <= Math.pow(num,2);k++){
            if (data[i][j] == 0){
                data[i][j] = k;
                if (data[i+1 >= num ? 0 : i+1][j+1 >= num ? 0 : j+1] == 0){
                    i = i+1 >= num ? 0 : i+1;
                    j = j+1 >= num ? 0 : j+1;
                }
                else{
                    i = i-1 < 0 ? num-1 : i-1;
                }
            }
        }
    }
    public String toString(){
        String num_table = "";
        for(int[] e : data){
            for(int i : e){
                num_table += i + "\t";
            }
            num_table += "\n";
        }
        return num_table;
    }
}

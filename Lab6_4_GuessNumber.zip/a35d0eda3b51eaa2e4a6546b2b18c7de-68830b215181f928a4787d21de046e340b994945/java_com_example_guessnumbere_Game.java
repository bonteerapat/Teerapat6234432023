package com.example.guessnumbere;

import java.util.Random;

public class Game {
    private int num;
    public Game(){
        Random rand = new Random();
        num = rand.nextInt(100);
        num += 1;
    }
    public String Guess(int guess_num){
        String check;
        if(guess_num > num){
            check = "Your guess is too high";
        }else if(guess_num < num){
            check = "Your guess is too low";
        }else{
            check = "You won";
        }
        return check;
    }
}

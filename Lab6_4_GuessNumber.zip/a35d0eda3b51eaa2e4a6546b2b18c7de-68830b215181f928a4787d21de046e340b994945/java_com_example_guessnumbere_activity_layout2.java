package com.example.guessnumbere;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class activity_layout2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout2);
        Button guess = findViewById(R.id.guess);
        final EditText inputNum = findViewById(R.id.inputNum);
        final TextView out = findViewById(R.id.out);
        final Game game = new Game();
        guess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String check = inputNum.getText().toString();
                if(check.length() <= 3 && check.length() != 0){
                    int num = Integer.parseInt(check);
                    String var = game.Guess(num);
                    out.setText(var);
                    if(var == "You won"){
                        startActivity(new Intent(activity_layout2.this,YouWon.class));
                        inputNum.setText("");
                        finish();
                    }else{
                        out.setText(var);
                        inputNum.setText("");
                    }
                }
            }
        });
    }
}

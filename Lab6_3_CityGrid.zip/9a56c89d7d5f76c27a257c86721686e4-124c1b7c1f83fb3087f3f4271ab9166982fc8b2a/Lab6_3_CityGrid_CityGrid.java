package Lab6_3_CityGrid;

import java.util.Random;

public class CityGrid {
    private int xCoor;
    private int yCoor;
    private final int gridSize;
    private final int x,y;
    public CityGrid(int x, int y){
        this.xCoor = x/2;
        this.x = x;
        this.yCoor = y/2;
        this.y = y;
        this.gridSize = x*y;
    }
    public void walk(){
        Random rand = new Random();
        int walk = rand.nextInt(4);
        switch(walk){
            case 0: xCoor++; break;
            case 1: xCoor--; break;
            case 2: yCoor++; break;
            case 3: yCoor--; break;
        }
    }
    public boolean isInCity(){
        if((xCoor<0 || xCoor>x) || (yCoor<0 || yCoor>y)){
            return false;
        }
        else{
            return true;
        }
    }
    public void reset(){
        xCoor=x/2;
        yCoor=y/2;
    }
}

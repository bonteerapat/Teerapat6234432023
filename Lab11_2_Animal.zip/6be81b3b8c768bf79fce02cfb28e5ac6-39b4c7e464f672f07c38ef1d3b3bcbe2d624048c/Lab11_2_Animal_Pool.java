package Lab11_2_Animal;

public class Pool extends Terrain {
    public Pool(String pool){
        super(pool);
    }
    public boolean canMove(Animal animal){
        if(animal instanceof CanSwim){
            return true;
        }
        return false;
    }
}

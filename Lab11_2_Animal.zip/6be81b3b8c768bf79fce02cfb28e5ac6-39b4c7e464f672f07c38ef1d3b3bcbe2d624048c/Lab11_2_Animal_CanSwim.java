package Lab11_2_Animal;

public interface CanSwim {
    void swim(Terrain terrain);
}

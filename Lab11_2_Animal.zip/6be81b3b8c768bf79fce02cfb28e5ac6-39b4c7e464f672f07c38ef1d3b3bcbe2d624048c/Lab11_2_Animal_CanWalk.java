package Lab11_2_Animal;

public interface CanWalk {
    void walk(Terrain terrain);
    void run(Terrain terrain);
}

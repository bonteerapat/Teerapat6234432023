package Lab11_2_Animal;

public class Sky extends Terrain {
    public Sky(String sky){
        super(sky);
    }
    public boolean canMove(Animal animal){
        if(animal instanceof CanFly) {
            return true;
        }
        return false;
    }
}

package Lab11_2_Animal;

public class Ground extends Terrain{
    public Ground(String ground){
        super(ground);
    }
    public boolean canMove(Animal animal){
        if(animal instanceof CanWalk){
            return true;
        }
        return  false;
    }
}

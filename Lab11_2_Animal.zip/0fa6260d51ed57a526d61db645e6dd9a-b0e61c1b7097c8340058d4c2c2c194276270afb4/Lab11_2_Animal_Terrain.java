package Lab11_2_Animal;

public abstract class Terrain {
    // instance variable
    private String name;
    // constructor
    public Terrain(String name){
        this.name = name;
    }
    // method
    public void setName(String set_name){
        name = set_name;
    }
    public String getName(){
        return name;
    }
    public abstract boolean canMove(Animal animal);
}

package Lab11_2_Animal;

public abstract class Animal {
    // instance variable
    private String name;
    // constructor
    public Animal(String name){
        this.name = name;
    }
    // method
    public void setName(String set_name){
        name = set_name;
    }
    public String getName(){
        return name;
    }
}

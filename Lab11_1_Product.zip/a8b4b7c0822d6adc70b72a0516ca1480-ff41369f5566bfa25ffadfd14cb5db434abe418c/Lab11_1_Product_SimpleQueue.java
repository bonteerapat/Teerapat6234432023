package Lab11_1_Product;

public interface SimpleQueue {
    void enqueue(Object o);
    void dequeue();
}

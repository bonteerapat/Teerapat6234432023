package Lab11_1_Product;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue {
    // instance variable
    private ArrayList<String> queue_song;
    private int count_queue;
    // constructor
    public MusicBox(){
        queue_song = new ArrayList<>();
        count_queue = 0;
    }
    // method
    public void enqueue(Object o){
        String song = "";
        if(o instanceof String){
            song = (String) o;
        }else{
            return;
        }
        queue_song.add(song);
        System.out.println(song + " is added in queue");
        count_queue++;
    }
    public void dequeue(){
        System.out.println("Now playing " + queue_song.get(0));
        queue_song.remove(0);
        if(count_queue == 0){
            return;
        }
        count_queue--;
    }
}

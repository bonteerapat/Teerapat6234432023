package Lab11_1_Product;

import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue {
    // instance variable
    private ArrayList<Product> queue_product;
    private Product pd;
    private double total_price;
    private int count_queue;
    // constructor
    public SelfCheckOut(){
        queue_product = new ArrayList<>();
        total_price = 0;
        count_queue = 0;
    }
    // method
    public void enqueue(Object o){
        if(o instanceof Product){
            pd = (Product) o;
        }else{
            return;
        }
        queue_product.add(pd);
        System.out.println(pd.getName() + " is added in queue");
        count_queue++;
    }
    public void dequeue(){
        total_price += queue_product.get(0).getPrice();
        queue_product.remove(0);
        if(count_queue == 0){
            return;
        }
        count_queue--;
    }
    public double getAmount(){
        return total_price;
    }
}

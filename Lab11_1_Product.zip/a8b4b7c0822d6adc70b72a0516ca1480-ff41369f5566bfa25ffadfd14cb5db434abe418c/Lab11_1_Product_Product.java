package Lab11_1_Product;

public class Product {
    // instance variable
    private String name;
    private double price;
    // constructor
    public Product(String n,double p){
        name = n;
        price = p;
    }
    // method
    public String getName(){
        return name;
    }
    public double getPrice(){
        return price;
    }
}

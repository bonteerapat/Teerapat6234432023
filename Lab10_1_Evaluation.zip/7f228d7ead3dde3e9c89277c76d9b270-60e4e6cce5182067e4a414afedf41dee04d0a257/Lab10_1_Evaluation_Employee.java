package Lab10_1_Evaluation;

public class Employee {
    // instance variable
    private String name;
    private int salary;
    // constructor
    public Employee(){
        name = "";
        salary = 0;
    }
    public Employee(String name,int salary){
        this.name = name;
        this.salary = salary;
    }
    // method
    public void setSalary(int salary){
        this.salary = salary;
    }
    public String getName(){
        return name;
    }
    public int getSalary(){
        return salary;
    }
    public String toString(){
        return getName() + "\n" + "salary = " + getSalary();
    }
}

package Lab10_1_Evaluation;

public class Secretary extends Employee implements Evaluation {
    // instance variable
    private int typingSpeed;
    private int[] score = new int[2];
    // constructor
    public Secretary(String name,int salary,int[] score,int typingSpeed){
        super(name, salary);
        this.score = score;
        this.typingSpeed = typingSpeed;
    }
    // method
    public int getTypingSpeed(){
        return typingSpeed;
    }
    public int[] getScore(){
        return score;
    }
    public double evaluate(){
        int total_score = 0;
        for(int i=0;i<score.length;i++){
            total_score += score[i];
        }
        return total_score;
    }
    public char grade(double total_score){
        total_score = this.evaluate();
        if(total_score >= 90){
            setSalary(18000);
            return 'P';
        }else{
            return 'F';
        }
    }

}

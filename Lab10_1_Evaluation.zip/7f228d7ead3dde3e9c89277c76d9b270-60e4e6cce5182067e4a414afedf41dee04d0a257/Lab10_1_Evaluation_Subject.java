package Lab10_1_Evaluation;

public class Subject implements Evaluation {
    // instance variable
    private String subjName;
    private int[] score;
    // constructor
    public Subject(String subject_Name,int[] score_array){
        subjName = subject_Name;
        score = score_array;
    }
    // method
    public double evaluate(){
        double total_score = 0;
        for(int i=0;i<score.length;i++){
            total_score += score[i];
        }
        double avg_score = total_score/score.length;
        return avg_score;
    }
    public char grade(double avg_score){
        avg_score = this.evaluate();
        if(avg_score >= 70){
            return 'P';
        }else{
            return 'F';
        }
    }
    public String toString(){
        return subjName;
    }
}

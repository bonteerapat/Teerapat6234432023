package Lab4_1_SodaCan;

import java.util.Scanner;

public class SodaCanTester {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter height : ");
        double height = input.nextDouble();
        System.out.print("Enter diameter : ");
        double diameter = input.nextDouble();

        SodaCan soda = new SodaCan(height,diameter);
        System.out.printf("Volume : %.2f \n",(float) soda.getVolume());
        System.out.printf("Surface area : %.2f \n",(float) soda.getSurfaceArea());

    }
}

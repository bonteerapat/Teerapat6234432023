package Lab12_2_WordContain;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class WordContain {
    public static void main(String[] args){
         File file = new File("wordlist.txt");
        Scanner file_scan = null;
        ArrayList<String> wordList = new ArrayList<>();
        try{
            file_scan = new Scanner(file);
            while(file_scan.hasNextLine()){
                String line = file_scan.nextLine();
                wordList.add(line);
            }
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }finally {
            if(file_scan != null){
                file_scan.close();
            }
        }
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a sentence : ");
        String text_input = input.nextLine();

        String word_not_contain = "";
        boolean contain = true;
        String[] words = text_input.split(" ");
        for(String word : words){
            if(!wordList.contains(word)){
                contain = false;
                word_not_contain += word;
                word_not_contain += " ";
            }
        }
        System.out.println("Words not contained : ");
        if(contain){
            System.out.println("N/A");
        }else{
            System.out.println(word_not_contain);
        }
    }
}

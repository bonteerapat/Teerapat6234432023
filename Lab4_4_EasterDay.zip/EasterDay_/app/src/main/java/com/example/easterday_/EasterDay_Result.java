package com.example.easterday_;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class EasterDay_Result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.easter_day_result);

        if(getIntent().hasExtra("com.example.easter_day_.result")){
            TextView tv = (TextView) findViewById(R.id.resultText);
            String text = getIntent().getExtras().getString("com.example.easter_day_.result");
            tv.setText(text);
        }
    }
}

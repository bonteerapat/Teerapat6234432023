package Lab4_3_TimeInterval;

public class TimeInterval {
    private int start;
    private int end;
    private int hour;
    private int minute;
    public TimeInterval(int s,int e){
        start = s;
        end = e;
        hour = 0;
        minute = 0;
    }
    public int getHours(){
        hour = (start/100)-(end/100);
        // hour = time/100
        return Math.abs(hour);
    }
    public int getMinutes(){
        minute = (start - (start/100*100))-(end-(end/100*100));
        // minute = time-(time/100*100)
        return Math.abs(minute);
    }

}

package Lab4_3_TimeInterval;

import java.util.Scanner;

public class TimeIntervalTester {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter start time : ");
        int start = input.nextInt();
        System.out.print("Enter end time : ");
        int end = input.nextInt();

        TimeInterval time = new TimeInterval(start,end);
        int hour = time.getHours();
        int minute = time.getMinutes();
        System.out.println(hour + " hours " + minute + " minutes ");
    }
}

package Lab6_1_CannonBall;

public class CannonBall {
    private double initV; // u
    private double simS; // distance in simulation
    private double simT; // time in simulation
    public static final double g = 9.81;
    public CannonBall(int initV){
        this.initV = initV;
    }
    public void simulatedFlight(){
        double delta_T = 0.01;
        double v = initV;
        double delta_S;
        int time = 0;
        int second = 1;
        while(v > 0){
            delta_S = v*delta_T;
            v -= (g*delta_T);
            simS += delta_S;
            simT += delta_T;
            time += 1;
            if(time == 100){
                System.out.printf("Distance on %d sec : %.3f \n",second,simS);
                time = 0;
                second += 1;
            }
        }
    }
    public double calculusFlight(double t){
        double s = (-0.5)*g*Math.pow(t,2) + initV*t;
        System.out.printf("Final distance : %.3f Total time : %.2f \n",simS,simT);
        return Math.round(s*1000)/1000.000;
    }
    public double getSimulatedTime(){
        return simT;
    }
    public double getSimulatedDistance(){
        return simS;
    }
}

package Lab7_1_Purse;

public class PurseTester {
    public static void main(String[] args){
        Purse a = new Purse();
        a.addCoin("Nickel");
        a.addCoin("Quater");
        a.addCoin("Nickel");
        a.addCoin("Dime");
        System.out.println("purse A : " + a.toString());
        Purse b = new Purse();
        b.addCoin("Quater");
        b.addCoin("Dime");
        b.addCoin("Nickel");
        b.addCoin("Nickel");
        System.out.println("purse B : " + b.toString());
        System.out.println("--- Reverse ---");
        b.reverse();
        System.out.println("reverse_purse B : " + b.toString());
        System.out.println("Same coins : " + a.sameCoins(b));
        System.out.println("Same content : " + a.sameContents(b));
        a.transfer(b);
        System.out.println("--- Transfer ---");
        System.out.println("purse A : " + a.toString());
        System.out.println("purse B : " + b.toString());
        System.out.println("Same coins : " + a.sameCoins(b));
        System.out.println("Same content : " + a.sameContents(b));
    }
}

package Lab7_1_Purse;

import java.util.ArrayList;

public class Purse {
    private ArrayList purse;
    private ArrayList reverse_purse;
    private ArrayList check;
    public Purse(){
        purse = new ArrayList<String>();
        reverse_purse = new ArrayList<String>();
    }
    public void addCoin(String coinName){
        purse.add(coinName);
    }
    @Override
    public String toString(){
        if (purse.size() == 0){
            return "Purse[]";
        }
        String array_purse = "Purse[";
        for (Object coin : purse){
            array_purse = array_purse + coin + ",";
        }
        array_purse = array_purse.substring(0, array_purse.length() - 1);
        return array_purse + "]";
    }
    public ArrayList<String> reverse(){
        for(int i=purse.size()-1;i>=0;i--){
            reverse_purse.add((String) purse.get(i));
        }
        purse = reverse_purse;
        return purse;
    }
    public void transfer(Purse other){
        for(Object coin : this.purse){
            other.purse.add(coin);
        }
        this.purse.clear();
    }
    public boolean sameContents(Purse other){
        boolean equation = true;
        if(purse.size()==other.purse.size()){
            for(int i=0;i<purse.size();i++){
                equation = purse.get(i).equals(other.purse.get(i));
            }
        }
        else equation = false;
        return equation;
    }
    public boolean sameCoins(Purse other){
        check=(ArrayList) other.purse.clone();
        boolean equal = true;
        if(purse.size()==other.purse.size()){
            for(int i=0;i<purse.size();i++){
                boolean delete = false;
                for(int j=0;j<check.size()&&!delete;j++){
                    if (purse.get(i) == check.get(j)){
                        check.remove(j);
                        delete = true;
                    }
                }
                if(!delete) equal = false;
            }
        }
        else equal = false;
        return equal;
    }
}
